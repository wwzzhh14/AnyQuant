package businesslogicservice.visualizationlogicservice;

import javax.swing.*;

/**
 * Created by Jiayiwu on 16/4/2.
 */
public interface VisualizationRecommendPanel {
//该方法默认返回当天数据以及15天内的行业趋势
    public JPanel getScatterPanel();

}
